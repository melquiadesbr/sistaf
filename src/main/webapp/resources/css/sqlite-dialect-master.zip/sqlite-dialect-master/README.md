Hibernate dialect for SQLite inspired from the NHibernate one.

[![Build Status][1]][2]

First posted on [14 Mar 23:08 2008](http://permalink.gmane.org/gmane.comp.db.sqlite.jdbc/637)

[1]: https://secure.travis-ci.org/gwenn/sqlite-dialect.png
[2]: http://www.travis-ci.org/gwenn/sqlite-dialect
